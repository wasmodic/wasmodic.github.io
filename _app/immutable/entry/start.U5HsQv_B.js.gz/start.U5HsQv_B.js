import{l as o,a as r}from"../chunks/CQ3L6A9s.js";export{o as load_css,r as start};

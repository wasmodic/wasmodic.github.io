import{l as o,a as r}from"../chunks/BPmYR7jO.js";export{o as load_css,r as start};

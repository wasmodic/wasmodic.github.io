import{l as o,a as r}from"../chunks/YYc3Mw1H.js";export{o as load_css,r as start};
